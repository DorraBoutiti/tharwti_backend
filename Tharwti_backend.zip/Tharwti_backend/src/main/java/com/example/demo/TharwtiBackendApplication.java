package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TharwtiBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TharwtiBackendApplication.class, args);
	}

}
